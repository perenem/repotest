package com.myboard.repository;

import com.myboard.entity.Article;
import com.myboard.entity.Comment;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
@Transactional
class CommentRepositoryTest {
    @Autowired
    CommentRepository commentRepository;

    @Autowired
    ArticleRepository articleRepository;

    @Test
    @DisplayName("모든 자료 검색")
    void findAllTest() {
        //Given
        int articleCount = 6;
        //When
        int resultCount = (int) articleRepository.findAll().stream().count();

        //Then
        assertThat(resultCount).isEqualTo(articleCount);
    }

    @Test
    @DisplayName("특정 자료 검색")
    void findByOneId() {
        //Given
        Article expetedArticle = new Article(1L, "가가가가", "1111");
        //When
        Long id = 1L;
        Article searchArticle = articleRepository.findById(id).get();

        //Then
        assertThat(searchArticle).isEqualTo(expetedArticle);
    }

    @Test
    @DisplayName("특정 자료 검색 실패")
    void findByOneIdFail() {
        //Given
        Article expetedArticle = new Article(1L, "가가가", "1111");
        //When
        Long id = 1L;
        Article searchArticle = articleRepository.findById(id).get();

        //Then
        assertThat(searchArticle).isNotEqualTo(expetedArticle);
    }

    @Test
    @DisplayName("자료입력테스트")
    void articleInsertTest() {
        //Given
        Article dataArticle = new Article(null, "라라라", "444");
        //When
        articleRepository.save(dataArticle);
        Article expectedArticle = articleRepository.findById(7L).get();

        //Then
        assertThat(expectedArticle).isEqualTo(dataArticle);
    }

    @Test
    @DisplayName("자료수정테스트")
    void articleUpdateTest() {
        //Given
        Article dataArticle = new Article(1L, "수정", "수정컨텐트");
        //When
        articleRepository.save(dataArticle);
        Article expectedArticle = articleRepository.findById(1L).get();

        //Then
        assertThat(expectedArticle).isEqualTo(dataArticle);
    }

    @Test
    @DisplayName("자료삭제테스트")
    void articleDeleteTest() {
        //Given
        Long deleteId = 1L;
        Article dataArticle = new Article(1L, "가가가가", "1111");
        //When
        articleRepository.deleteById(deleteId);
        Article expectedArticle = articleRepository.findById(1L).orElse(null);

        //Then
        assertThat(expectedArticle).isEqualTo(null);
    }



    @Test
    @DisplayName("특정 게시글의 모든 댓글 조회")
    void findByArticleId() {
        // Given
        Long articleId = 4L;

        // When
        List<Comment> comments = commentRepository.findByArticleId(articleId);

        // Then
        assertThat(comments.stream().count()).isEqualTo(3);
    }

    @Test
    @DisplayName("특정 닉네임의 모든 댓글 조회")
    void findByNickname() {
        // Given
        // Park의 모든 댓글 조회
        String nickname = "Park";

        // When
        List<Comment> comments = commentRepository.findByNickname(nickname);
        // Then
        Comment a = new Comment(1L, new Article(4L, "당신의 인생 영화는?", "댓글 고"), nickname, "굿 윌 헌팅");
        Comment b = new Comment(4L, new Article(5L, "당신의 소울 푸드는?", "댓글 고고"), nickname, "치킨");
        Comment c = new Comment(7L, new Article(6L, "당신의 취미는?", "댓글 고고고"), nickname, "조깅");
        List<Comment> expected = Arrays.asList(a, b, c);

        assertThat(expected.toString()).isEqualTo(comments.toString());

    }
}