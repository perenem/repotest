package com.myboard.service;

import com.myboard.dto.CommentDto;
import com.myboard.entity.Article;
import com.myboard.entity.Comment;
import com.myboard.repository.ArticleRepository;
import com.myboard.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentService {
    @Autowired
    CommentRepository commentRepository;

    @Autowired
    ArticleRepository articleRepository;


    public CommentDto create(Long articleId, CommentDto dto) {
        //1.부모게시글을 조회해서 없는 경우 오류처리
        Article article = articleRepository.findById(articleId)
                .orElseThrow( () -> new IllegalArgumentException("댓글 등록 실패"));
        //2. 댓글 엔티티 생성
        Comment comment = new Comment();
        comment.setArticle(article);
        comment.setNickname(dto.getNickname());
        comment.setBody(dto.getBody());
        //3. 댓글 저장
        Comment created = commentRepository.save(comment);
        //4.결과를 DTO로 리턴
        return CommentDto.createCommentDto(created);
    }


    public List<CommentDto> comments(Long id) {
        //1. 댓글조회
        List<Comment> comments = commentRepository.findByArticleId(id);
        //2. 엔티티 -> DTO 로 변환

        //3. 결과 반환(Return)
        return comments.stream()
                .map(x ->CommentDto.createCommentDto(x))
                .toList();
    }

    public CommentDto update(Long id, CommentDto dto) {
        // 1. 댓글 조회 및 예외발생
        Comment target = commentRepository
                .findById(id)
                .orElseThrow( () ->new IllegalArgumentException("댓글 수정 실패! " +
                        "대상 댓글이 없습니다."));
        // 2. 댓글 수정
        target.patch(dto);

        // 3. Db 갱신
        Comment updated = commentRepository.save(target);

        // 4. 댓글 엔티티를 DTO 로 변환 후 리턴
        return CommentDto.createCommentDto(updated);
    }

}
