package com.myboard.api;

import com.myboard.dto.CommentDto;
import com.myboard.service.CommentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
public class CommentApiController {

    @Autowired
    CommentService commentService;


    //1.댓글조회하기
    @GetMapping("/api/articles/{articleId}/comments")
    public ResponseEntity<List<CommentDto>> articleComments(@PathVariable Long articleId){
        //서비스에 요청
        List<CommentDto> dtos = commentService.comments(articleId);
        //결과 리턴
        return ResponseEntity.status(HttpStatus.OK).body(dtos);
    }


    //2.댓글생성하기
    @PostMapping("/api/articles/{articleId}/comments")
    public CommentDto create(@PathVariable Long articleId,
                             @RequestBody CommentDto dto){
        //서비스처리
        CommentDto createdDto = commentService.create(articleId, dto);
        //리턴
        return null;
    }
    //3.댓글수정하기
    @PatchMapping("/api/comments/{id}")
    public CommentDto update(@PathVariable Long id,
                             @RequestBody CommentDto dto){
//      log.info(dto.toString);
        //서비스에서 처리
        CommentDto updateDto = commentService.update(id, dto);
        //결과 응답
        return updateDto;
    }

    //4.댓글삭제하기
    @DeleteMapping("/api/comments/{id}")
    public CommentDto delete(@PathVariable Long id){
        //서비스 호출
        CommentDto deletedDto = commentService.delete(id);
        //결과 전송
        return deletedDto;
    }
}
