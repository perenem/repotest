package com.myboard.api;

import com.myboard.dto.ArticleForm;
import com.myboard.entity.Article;
import com.myboard.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ArticleApiController {
//ArticleService 에 모든 내용들이 있다. 연동해서 확인하기//
    @Autowired
    ArticleService articleService;

    @GetMapping("/api/articles")
    public List<Article> listAll(){
        return articleService.showAllList();
    }

    @GetMapping("/api/articles/{id}")
    public Article showListOne(@PathVariable("id")Long id){
        return articleService.showOneList(id);
    }

    @PostMapping("/api/articles")
    public Article createArticle(@RequestBody ArticleForm dto){
        return articleService.createArticle(dto);
    }

    @PatchMapping("/api/articles/{id}")
    public ResponseEntity<Article> updateArticle(@PathVariable("id")Long id,
                                                @RequestBody ArticleForm dto){
        return articleService.patchUpdate(id, dto);
    }

    @DeleteMapping("/api/articles/{id}")
    public ResponseEntity<Article> delete(@PathVariable("id")Long id){
        return articleService.delete(id);
    }
}
