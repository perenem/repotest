package com.myboard.service;

import com.myboard.dto.CommentDto;
import com.myboard.entity.Comment;
import com.myboard.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentService {
    @Autowired
    CommentRepository commentRepository;
    public List<CommentDto> comments(Long id) {
        //1. 댓글조회
        List<Comment> comments = commentRepository.findByArticleId(id);
        //2. 엔티티 -> DTO 로 변환

        //3. 결과 반환(Return)
        return comments.stream()
                .map(x ->CommentDto.createCommentDto(x))
                .toList();
    }

    public CommentDto update(Long id, CommentDto dto) {
        // 1. 댓글 조회 및 예외발생
        Comment target = commentRepository
                .findById(id)
                .orElseThrow( () ->new IllegalArgumentException("댓글 수정 실패! " +
                        "대상 댓글이 없습니다."));
        // 2. 댓글 수정
        target.patch(dto);

        // 3. Db 갱신
        Comment updated = commentRepository.save(target);

        // 4. 댓글 엔티티를 DTO 로 변환 후 리턴
        return CommentDto.createCommentDto(updated);
    }

    public CommentDto delete(Long id) {
        //1. 댓글 조회 및 예외 발생 처리
        Comment target = commentRepository.findById(id)
                .orElseThrow( () -> new IllegalArgumentException("댓글 삭제 실패"));
        //2. 댓글 삭제
        commentRepository.delete(target);
        //3.삭제한 댓글 DTO로 변환 및 리턴
        return CommentDto.createCommentDto(target);
    }
}
