package com.myboard.entity;

import com.myboard.dto.CommentDto;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter

public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name="article_id")
    private Article article;
    private String nickname;
    private String body;

    public void patch(CommentDto dto) {
        if (dto.getId() != this.id) {
            throw new IllegalArgumentException("댓글수정 실패! 잘못된 ID 입니다.");
        }

        // 객체를 바꿔줍니다.
        if (dto.getNickname() != null) {
            this.nickname = dto.getNickname();
        }
        if (dto.getBody() != null) {
            this.body = dto.getBody();
        }
    }
}
